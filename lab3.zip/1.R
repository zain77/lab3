attach(mtcars)
plot(gear, mpg, main = "No. of gears vs. Mileage", xlab = "No. of gears", ylab = "Mileage",
    pch = 15, col = "green")
text(gear, mpg, row.names(mtcars), cex = 0.7, pos = 4, col = "forestgreen")


