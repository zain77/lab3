attach(mtcars)
plot(hp, drat, main = "Horsepower vs. Draft", xlab = "Horsepower", ylab = "Draft",
     pch = 15, col = "green")
text(hp, drat, row.names(mtcars), cex = 0.7, pos = 4, col = "forestgreen")
